<?php
// functions.php — MIGP Theme

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function migp_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    register_nav_menus( array(
        'primary' => 'Primary Menu',
    ) );
}
add_action( 'after_setup_theme', 'migp_theme_setup' );

function migp_enqueue_assets() {
    // Enqueue main theme stylesheet (copy the original styles into /assets/styles.css)
    wp_enqueue_style( 'migp-main', get_stylesheet_directory_uri() . '/assets/styles.css', array(), filemtime( get_stylesheet_directory() . '/assets/styles.css' ) );

    // Enqueue theme scripts (copy scripts.js into /assets/scripts.js)
    wp_enqueue_script( 'migp-scripts', get_stylesheet_directory_uri() . '/assets/scripts.js', array(), filemtime( get_stylesheet_directory() . '/assets/scripts.js' ), true );
}
add_action( 'wp_enqueue_scripts', 'migp_enqueue_assets' );

// Load REST API endpoints
require_once get_stylesheet_directory() . '/inc/rest-api.php';

/* Register custom post types: Events and Pastors */
function migp_register_cpts() {
    // Events
    $labels = array(
        'name' => 'Eventos',
        'singular_name' => 'Evento',
    );
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'supports' => array('title','editor','custom-fields','thumbnail'),
        'rewrite' => array('slug' => 'eventos'),
    );
    register_post_type( 'migp_event', $args );

    // Pastors
    $labels = array(
        'name' => 'Pastores',
        'singular_name' => 'Pastor',
    );
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'supports' => array('title','editor','thumbnail','excerpt'),
        'rewrite' => array('slug' => 'pastores'),
    );
    register_post_type( 'migp_pastor', $args );
}
add_action( 'init', 'migp_register_cpts' );

/* Shortcode to render a simple Events list (used by front-page or pages) */
function migp_events_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'posts' => 10,
    ), $atts, 'migp_events' );

    $q = new WP_Query( array(
        'post_type' => 'migp_event',
        'posts_per_page' => intval( $atts['posts'] ),
        'orderby' => 'meta_value',
        'meta_key' => 'event_date',
        'order' => 'ASC',
    ) );

    ob_start();
    echo '<div class="migp-events-wrap">';
    if ( $q->have_posts() ) {
        echo '<ul class="migp-events-list">';
        while( $q->have_posts() ) { $q->the_post();
            $date = get_post_meta( get_the_ID(), 'event_date', true );
            $time = get_post_meta( get_the_ID(), 'event_time', true );
            echo '<li class="migp-event-item">';
            echo '<strong>' . get_the_title() . '</strong>';
            if ( $date ) echo ' — <time>' . esc_html( $date );
            if ( $time ) echo ' ' . esc_html( $time );
            echo '</time>';
            echo '<div class="desc">' . get_the_excerpt() . '</div>';
            echo '</li>';
        }
        echo '</ul>';
        wp_reset_postdata();
    } else {
        echo '<p>No hay eventos programados.</p>';
    }
    echo '</div>';

    return ob_get_clean();
}
add_shortcode( 'migp_events', 'migp_events_shortcode' );

/* Helpers: allow SVG uploads (optional) */
function migp_mime_types($mimes) {
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter('upload_mimes', 'migp_mime_types');

?>