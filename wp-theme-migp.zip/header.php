<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="site-header">
  <div class="container header-inner">
    <a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
      <?php if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) { the_custom_logo(); } else { ?><img class="site-logo" src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/logo-white.png' ); ?>" alt="<?php bloginfo('name'); ?>"><?php } ?>
      <span class="logo-text"><?php bloginfo('name'); ?></span>
    </a>
    <button class="nav-toggle" aria-label="Abrir menú">☰</button>
    <nav class="site-nav">
      <?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'items_wrap' => '%3$s' ) ); ?>
    </nav>
  </div>
</header>
<main>
