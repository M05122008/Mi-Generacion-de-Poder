MIGP WordPress Theme — instrucciones rápidas

1) Instalación
- Copia la carpeta `wp-theme-migp` a `wp-content/themes/` de tu instalación WordPress.
- Copia los siguientes archivos/carpetas desde tu sitio estático al tema:
  - `styles.css` (si no quieres usar la import desde `style.css`),
  - `scripts.js`,
  - carpeta `assets/` con logos y fotos.
- Activa el tema desde Apariencia → Temas.

2) Registrar menú
- Ve a Apariencia → Menús y asigna el menú a la ubicación "Primary Menu".

3) Pastores y Eventos
- En el panel WP aparecerán dos tipos de contenido: "Pastores" y "Eventos".
- Añade pastores (titulo, descripción corta y featured image) y eventos (usa campos personalizados `event_date` y `event_time` si deseas que aparezcan en el listado).

4) Personalización rápida
- Puedes pegar el HTML de tu `index.html` en la página que asignes como portada (Ajustes → Lectura → Página estática) o editar `front-page.php` para renderizar secciones automáticamente.

5) Notas técnicas
- `functions.php` registra CPTs y un shortcode `[migp_events]` que muestra eventos. Para un calendario interactivo necesitarás adaptar el script JS para consumir los metadatos de los eventos o usar un plugin de calendario.

Si quieres, adapto ahora todo el HTML de `index.html` a `front-page.php` (reemplazando rutas y enlaces) para que la home quede exactamente igual. ¿Deseas que lo haga ahora? 
