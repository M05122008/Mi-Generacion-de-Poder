</main>
<footer class="site-footer">
  <div class="container footer-grid">
    <div class="footer-brand">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/logo-color.jpg' ); ?>" alt="<?php bloginfo('name'); ?>" class="footer-logo">
      <p>Ministerio Internacional Generación de Poder — Tamacá, Barquisimeto.</p>
    </div>
    <div class="footer-links">
      <h4>Enlaces</h4>
      <nav>
        <?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false ) ); ?>
      </nav>
    </div>
    <div class="footer-contact">
      <h4>Contacto</h4>
      <p class="muted">migeneraciondepoder@gmail.com<br>
      <a class="footer-phone" href="https://api.whatsapp.com/send/?phone=%2B584245620960&text&type=phone_number&app_absent=0">+58 (424) 562-0960</a></p>
    </div>
    <div class="footer-social">
      <h4>Síguenos</h4>
      <a class="card" href="https://www.instagram.com/migeneraciondepoder/" target="_blank" rel="noopener">Instagram</a>
    </div>
  </div>
  <div class="container" style="border-top:1px solid rgba(255,255,255,0.03);margin-top:1rem;padding-top:1rem;text-align:center">
    <p>© <?php echo date('Y'); ?> <?php bloginfo('name'); ?></p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>