<?php get_header(); ?>
<main class="container">
  <h1>Eventos</h1>
  <?php
  $q = new WP_Query(array('post_type'=>'migp_event','posts_per_page'=>20));
  if($q->have_posts()):
    echo '<ul class="events-archive">';
    while($q->have_posts()): $q->the_post();
      echo '<li><a href="'. get_permalink() .'">'. get_the_title() .'</a> — '. esc_html( get_post_meta( get_the_ID(), 'event_date', true ) ) .'</li>';
    endwhile;
    echo '</ul>';
    wp_reset_postdata();
  else:
    echo '<p>No hay eventos.</p>';
  endif;
  ?>
</main>
<?php get_footer(); ?>