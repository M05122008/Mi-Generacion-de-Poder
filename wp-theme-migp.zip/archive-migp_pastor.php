<?php get_header(); ?>
<main class="container">
  <h1>Pastores</h1>
  <div class="grid staff-grid">
  <?php $q = new WP_Query(array('post_type'=>'migp_pastor','posts_per_page'=>20)); if($q->have_posts()): while($q->have_posts()): $q->the_post(); ?>
    <div class="staff-card">
      <?php if(has_post_thumbnail()) the_post_thumbnail('medium'); else echo '<img src="'. esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251027-WA0222.jpg' ) .'" alt="'. get_the_title() .'">'; ?>
      <div class="staff-body">
        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <div class="role"><?php echo get_post_meta( get_the_ID(), 'role', true ); ?></div>
        <p><?php the_excerpt(); ?></p>
      </div>
    </div>
  <?php endwhile; wp_reset_postdata(); else: echo '<p>No hay pastores.</p>'; endif; ?>
  </div>
</main>
<?php get_footer(); ?>