<?php get_header(); ?>
<main class="container">
  <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
    <article class="pastor-single staff-card">
      <?php if ( has_post_thumbnail() ) the_post_thumbnail( 'large' );
      else echo '<img src="'. esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251027-WA0222.jpg' ) .'" alt="'. get_the_title() .'">'; ?>
      <div class="staff-body">
        <h1><?php the_title(); ?></h1>
        <div class="role"><?php echo get_post_meta( get_the_ID(), 'role', true ); ?></div>
        <div class="content"><?php the_content(); ?></div>
      </div>
    </article>
  <?php endwhile; ?>
</main>
<?php get_footer(); ?>