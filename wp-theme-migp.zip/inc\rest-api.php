<?php
// REST API routes for MIGP theme
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'rest_api_init', function() {
    register_rest_route( 'migp/v1', '/events', array(
        'methods' => 'GET',
        'callback' => 'migp_rest_events',
        'permission_callback' => '__return_true',
    ) );
} );

function migp_rest_events( $request ){
    $args = array(
        'post_type' => 'migp_event',
        'posts_per_page' => -1,
        'post_status' => 'publish',
    );
    $q = new WP_Query( $args );
    $out = array();
    if ( $q->have_posts() ){
        while ( $q->have_posts() ){ $q->the_post();
            $id = get_the_ID();
            $out[] = array(
                'id' => $id,
                'title' => get_the_title(),
                'date' => get_post_meta( $id, 'event_date', true ),
                'time' => get_post_meta( $id, 'event_time', true ),
                'excerpt' => get_the_excerpt(),
                'content' => apply_filters( 'the_content', get_the_content() ),
                'link' => get_permalink( $id ),
            );
        }
        wp_reset_postdata();
    }
    return rest_ensure_response( $out );
}
?>