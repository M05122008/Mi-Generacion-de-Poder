<?php
/* Front Page template — converted from index.html. */
get_header();
?>

  <section class="hero">
    <div class="banner" id="banner" aria-hidden="false">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20250517-WA0034.jpg' ); ?>" alt="" class="banner-slide active">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251019-WA0228.jpg' ); ?>" alt="" class="banner-slide">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251014-WA0137.jpg' ); ?>" alt="" class="banner-slide">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251027-WA0123.jpg' ); ?>" alt="" class="banner-slide">
    </div>
    <div class="hero-overlay"></div>
    <div class="container hero-content">
      <h2>Bienvenidos a Ministerio Internacional Generación de Poder</h2>
      <p>Iglesia en Tamacá, Zona Norte — Barquisimeto, Lara, Venezuela</p>
      <div class="hero-cta">
        <a class="btn" href="#gallery">Ver Fotos</a>
        <a class="btn ghost" href="#location">Cómo llegar</a>
      </div>
    </div>
  </section>

  <section id="about" class="section container">
    <h3>Sobre Nosotros</h3>
    <p>
      El Ministerio Internacional Generación de Poder es un Ministerio Bajo la Cobertura de la Pastora Gisela Bracho El Rey Jesus Punto Fijo.
    </p>
    <p>
      La Mision de MIGP es una Iglesia  Apostólica y Profetica que Creemos en el Poder y la Manifestacion del Espíritu Santo.
    </p>
    <p>
      La Vision de MIGP es Evangelizar, Afirmar, Discipular y Enviar.
    </p>
  </section>

  <section id="gallery" class="section container">
    <h3>Galería de Fotos</h3>
    <p class="muted">Haz click en una imagen para verla en grande.</p>
    <div class="grid gallery-grid">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20250517-WA0034.jpg' ); ?>" alt="Servicio" data-type="image">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251019-WA0228.jpg' ); ?>" alt="Culto" data-type="image">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251014-WA0137.jpg' ); ?>" alt="Culto" data-type="image">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251027-WA0123.jpg' ); ?>" alt="Llamado" data-type="image">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251109-WA0364.jpg' ); ?>" alt="Predicación" data-type="image">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251108-WA0046.jpg' ); ?>" alt="Jóvenes" data-type="image">
    </div>
  </section>

  <section id="videos" class="section container">
    <h3>Videos</h3>
    <p class="muted">Revisa algunos de nuestros mensajes y momentos especiales.</p>
    <div class="grid video-grid">
      <div class="video-card" data-type="video" data-video-id="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/VID-20251109-WA0867.mp4' ); ?>">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/Imagen de WhatsApp 2025-11-15 a las 00.27.26_19966b52.jpg' ); ?>" alt="Video ejemplo">
        <div class="video-play">▶</div>
        <p>Adoracion</p>
      </div>
      <div class="video-card" data-type="video" data-video-id="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/VID-20251109-WA0797.mp4' ); ?>">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/Imagen de WhatsApp 2025-11-15 a las 00.27.26_e0e22f8c.jpg' ); ?>" alt="Video ejemplo">
        <div class="video-play">▶</div>
        <p>Servicio Sobrenatural</p>
      </div>
    </div>
  </section>

  <section id="pastors" class="section container">
    <h3>Pastores Principales</h3>
    <p class="muted">Conoce a nuestros pastores principales.</p>
    <div class="grid staff-grid">
      <?php
      $p = new WP_Query(array('post_type'=>'migp_pastor','posts_per_page'=>6));
      if ( $p->have_posts() ):
        while ( $p->have_posts() ): $p->the_post(); ?>
          <div class="staff-card animate" data-anim="fade-up">
            <?php if ( has_post_thumbnail() ) { the_post_thumbnail( array(260,260) ); } else { ?>
              <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251027-WA0222.jpg' ); ?>" alt="<?php the_title(); ?>" data-type="image">
            <?php } ?>
            <div class="staff-body">
              <h4><?php the_title(); ?></h4>
              <div class="role"><?php echo get_post_meta( get_the_ID(), 'role', true ); ?></div>
              <p><?php the_excerpt(); ?></p>
              <?php $ig = get_post_meta( get_the_ID(), 'instagram', true ); if ( $ig ) echo '<p><a class="ig-link" href="'. esc_url( $ig ) .'">'. esc_html( $ig ) .'</a></p>'; ?>
            </div>
          </div>
        <?php endwhile; wp_reset_postdata();
      else:
        // Fallback: show two hardcoded pastor cards from assets
      ?>
        <div class="staff-card animate" data-anim="fade-up">
          <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251027-WA0222.jpg' ); ?>" alt="Edgar Jimenez" data-type="image">
          <div class="staff-body">
            <h4>Edgar Jimenez</h4>
            <div class="role">Pastor Principal</div>
            <p>Pastor Edgar Jimenez lidera el Ministerio Internacional Generación de Poder, con una trayectoria de servicio, predicación y formación de líderes.</p>
            <p><a class="ig-link" href="https://www.instagram.com/soyedgarfrancisco/?__pwa=1">@soyedgarfrancisco</a></p>
          </div>
        </div>
        <div class="staff-card animate" data-anim="fade-up">
          <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/IMG-20251023-WA0139.jpg' ); ?>" alt="Sarahi de Jimenez" data-type="image">
          <div class="staff-body">
            <h4>Sarahi de Jimenez</h4>
            <div class="role">Pastora</div>
            <p>Pastora Sarahi de Jimenez acompaña el ministerio pastoral con enfoque en familias, jóvenes y ministración.</p>
            <p><a class="ig-link" href="https://www.instagram.com/sarahidejimenez/?__pwa=1">@sarahidejimenez</a></p>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </section>

  <section id="events" class="section container">
    <h3>Eventos</h3>
    <p class="muted">Consulta los próximos eventos y el calendario de actividades.</p>
    <div class="events-wrap">
      <div class="calendar-controls">
        <button id="prevMonth" aria-label="Mes anterior">‹</button>
        <div id="monthYear"></div>
        <button id="nextMonth" aria-label="Mes siguiente">›</button>
      </div>
      <div id="calendar" class="calendar-grid" aria-live="polite"></div>
      <div id="eventsList" class="events-list"></div>
      <div class="admin-controls">
        <button id="toggleAdmin" class="btn ghost">Administrar eventos</button>
      </div>
      <div id="eventAdmin" class="event-admin" hidden>
        <form id="eventForm">
          <div class="form-row">
            <label>Título<br><input type="text" id="eventTitle" required placeholder="Ej: Culto Dominical"></label>
          </div>
          <div class="form-row">
            <label>Fecha<br><input type="date" id="eventDate" required></label>
          </div>
          <div class="form-row">
            <label>Hora<br><input type="time" id="eventTime" placeholder="18:00"></label>
          </div>
          <div class="form-row">
            <label>Descripción<br><textarea id="eventDesc" rows="3" placeholder="Detalles del evento (opcional)"></textarea></label>
          </div>
          <div class="form-row">
            <button type="submit" class="btn">Agregar / Guardar</button>
            <button type="button" id="cancelEvent" class="btn ghost">Cancelar</button>
          </div>
        </form>
        <div id="adminEvents"></div>
      </div>
    </div>
  </section>

  <section id="location" class="section container">
    <h3>Ubicación</h3>
    <p class="muted">Estamos en Tamacá, Zona Norte — Barquisimeto, Lara, Venezuela.</p>
    <div class="map-wrap">
      <iframe src="https://www.google.com/maps?q=10.1885081,-69.3003197&z=17&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <p>Dirección: Ministerio Internacional Generación de Poder — Tamacá, Zona Norte, Barquisimeto.<br>
      <a href="https://www.google.com/maps/place/Ministerio+Internacional+Generaci%C3%B3n+de+Poder/@10.1885081,-69.3003197,17z" target="_blank" rel="noopener">Abrir en Google Maps</a></p>
  </section>

  <section id="contact" class="section container">
    <h3>Contacto</h3>
    <p class="muted">¿Tienes preguntas o quieres unirte? Escríbenos.</p>
    <div class="contact-cards">
      <a class="card" href="mailto:migeneraciondepoder@gmail.com">
        <svg class="icon social-icon email-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path d="M3 5.5C3 4.11929 4.11929 3 5.5 3H18.5C19.8807 3 21 4.11929 21 5.5V18.5C21 19.8807 19.8807 21 18.5 21H5.5C4.11929 21 3 19.8807 3 18.5V5.5Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M21 7L12 13L3 7" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        migeneraciondepoder@gmail.com
      </a>
      <a class="card" href="https://api.whatsapp.com/send/?phone=%2B584245620960&text&type=phone_number&app_absent=0">
        <svg class="icon social-icon whatsapp-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path d="M21 12.5C21 17.1944 16.9706 21 12 21C10.0106 21 8.18638 20.4296 6.75 19.4375L3 20.25L3.84375 16.5938C2.82188 15.1574 2.25 13.2721 2.25 11.25C2.25 6.55556 6.27941 3 11.25 3C16.2206 3 21 6.55556 21 11.25V12.5Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M17.25 15.75C16.3125 16.6875 15.0938 17.25 13.6875 17.25C11.0625 17.25 9 15.1875 9 12.5625C9 11.1562 9.5625 9.9375 10.5 9" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        +58 (424) 562-0960
      </a>
      <a class="card" href="https://www.instagram.com/migeneraciondepoder/" target="_blank" rel="noopener">
        <svg class="icon social-icon instagram-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <rect x="3" y="3" width="18" height="18" rx="5" stroke="currentColor" stroke-width="1.2"/>
          <path d="M16 11.37C15.7566 12.1433 15.1433 12.7566 14.37 13C13.5967 13.2434 12.7566 13.2434 11.9833 13C11.21 12.7566 10.5967 12.1433 10.3533 11.37C10.11 10.5967 10.11 9.7566 10.3533 8.98333C10.5967 8.21 11.21 7.59667 11.9833 7.35333C12.7566 7.11 13.5967 7.11 14.37 7.35333C15.1433 7.59667 15.7566 8.21 16 8.98333C16.2434 9.7566 16.2434 10.5967 16 11.37Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M17.5 6.5H17.51" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        Instagram
      </a>
    </div>
  </section>

<?php get_footer(); ?>